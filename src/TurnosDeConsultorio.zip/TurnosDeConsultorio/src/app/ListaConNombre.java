/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app;

import java.util.ArrayList;

/**
 *
 * @author Jose Tomas
 */
public class ListaConNombre {
    private String nombre;
    private ArrayList<String> lista;

    public ListaConNombre(String nombre) {
        this.nombre = nombre;
        this.lista = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public ArrayList<String> getLista() {
        return lista;
    }

    public String getNombreSinPrimeras2Letras() {
        return nombre.length() > 2 ? nombre.substring(2) : "";
    }
}
