/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package app;

import bridge.PantallaLED;
import bridge.Visualizador;
import java.util.Scanner;
import observer.AppMovil;
import observer.GestorTurnos;
import observer.Pantalla;
import proto.Turno;
import proto.TurnoPrototypeManager;
import single.ConfiguracionSistema;

/**
 *
 * @author Jose Tomas
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ConfiguracionSistema config = ConfiguracionSistema.getInstancia();
        Scanner scanner = new Scanner(System.in);
        GestorTurnos gestor = new GestorTurnos();
        
        Pantalla screen = new Pantalla("Lobby");
        AppMovil app = new AppMovil("Jose");
        
        gestor.agregarObservador(screen);
        gestor.agregarObservador(app);
        
        Visualizador visual1 = new PantallaLED(screen);
        Visualizador visual2 = new PantallaLED(app);

        System.out.println("--=Bienvenido a la Clinica=--");
        System.out.println("-Idioma: "+config.getIdioma());
        System.out.println("-Tiempo estimado entre Turnos: "+config.getTiempoEspera()+" min.");
        
        int opcion;
        
        while (true) {            
            System.out.println("\n===Menu Principal===");
            System.out.println("1. Emitir Turno Normal");
            System.out.println("2. Emitir Turno Urgente");
            System.out.println("3. Cambiar sala para proximos turnos");
            System.out.println("0. Salir");
            opcion = scanner.nextInt();
            scanner.nextLine();
            
            if(opcion == 1){
                emitirTurno("normal",gestor,scanner);
            }else if(opcion==2){
                emitirTurno("urgente",gestor,scanner);
            }else if(opcion==3){
                cambiarSala(scanner);
            }else if(opcion==0){
                System.out.println("!!!Saliendo...");
                break;
            }else{
                System.out.println("!!!Opcion no Valida");
            }
        }
        scanner.close();
    }
    private static String salaActual = "Sala General";
        
    private static void emitirTurno(String tipo, GestorTurnos gestor, Scanner scanner) {
        Turno turno = TurnoPrototypeManager.obtenerClon(tipo);
        if (turno != null) {
            turno.setSala(salaActual);
            gestor.llamarTurno(tipo);
            System.out.println("!!!Turno emitido para: " + salaActual);
        } else {
            System.out.println("!!!Tipo de turno inválido.");
        }
    }
    private static void cambiarSala(Scanner scanner) {
        System.out.print("-Ingrese el nombre de la nueva sala: ");
        salaActual = scanner.nextLine();
        System.out.println("️-La sala para próximos turnos ahora es: " + salaActual);
    }
}