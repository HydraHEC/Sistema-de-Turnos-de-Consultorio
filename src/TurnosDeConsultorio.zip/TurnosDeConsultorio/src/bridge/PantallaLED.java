/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bridge;

import observer.Observador;
import proto.Turno;

/**
 *
 * @author Jose Tomas
 */
public class PantallaLED extends Visualizador{

    public PantallaLED(Observador implementador) {
        super(implementador);
    }

    @Override
    public void mostrarTurno(Turno turno) {
        System.out.println("Pantalla ");
        implementador.actualizar(turno);
    }
    
}
