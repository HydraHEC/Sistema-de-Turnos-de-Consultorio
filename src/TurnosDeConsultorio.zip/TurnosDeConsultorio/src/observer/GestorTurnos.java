/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

import java.util.ArrayList;
import java.util.List;
import proto.Turno;
import proto.TurnoPrototypeManager;

/**
 *
 * @author Jose Tomas
 */
public class GestorTurnos {
    private List<Observador> observervadores = new ArrayList<>();
    private int contador = 1;
    
    public void agregarObservador(Observador obs){
        observervadores.add(obs);
    }
    
    public void quitarObservador(Observador obs){
        observervadores.remove(obs);
    }
    
    public void llamarTurno(String tipo){
        Turno turno = TurnoPrototypeManager.obtenerClon(tipo);
        if(turno != null){
            turno.setNumero(contador++);
            notificar(turno);
        }
    }
    
    public void notificar(Turno turno){
        for (Observador obs : observervadores){
            obs.actualizar(turno);
        }
    }
}
