/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

import proto.Turno;

/**
 *
 * @author Jose Tomas
 */
public class Pantalla implements Observador{
    private String nombre;
    
    public Pantalla(String nombre){
        this.nombre = nombre;   
    }
    
    @Override
    public void actualizar(Turno turno) {
        System.out.println("["+nombre+"] Mostrando Turno en Pantalla:");
        turno.mostrarInfo();
    }
}
