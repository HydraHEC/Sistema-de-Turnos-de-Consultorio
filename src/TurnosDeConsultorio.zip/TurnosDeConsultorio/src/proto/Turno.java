/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proto;

/**
 *
 * @author Jose Tomas
 */
public abstract class Turno implements Cloneable{
    protected String tipo;
    protected int numero;
    protected String sala;
    
    public Turno clonar(){
        try {
            return(Turno)super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
    
    public void mostrarInfo(){
        System.out.println("Turno: "+tipo+numero+" - sala:"+sala);
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setSala(String sala) {
        this.sala = sala;
    }
}
