/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proto;

import java.util.HashMap;

/**
 *
 * @author Jose Tomas
 */
public class TurnoPrototypeManager {
    private static HashMap<String, Turno> prototipos = new HashMap();
    
    static{
        prototipos.put("urgente",new TurnoUrgente());
        prototipos.put("normal",new TurnoNormal());
    }
    
    public static Turno obtenerClon(String tipo){
        Turno prototipo = prototipos.get(tipo.toLowerCase());
        if(prototipo != null){
            return prototipo.clonar();
        }else{
            return null;
        }
    }
}
