/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proto;

/**
 *
 * @author Jose Tomas
 */
public class TurnoUrgente extends Turno{
    public TurnoUrgente(){
        this.tipo = "U";
        this.sala = "Urgencias";
    }
}
