/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package single;

/**
 *
 * @author Jose Tomas
 */
public class ConfiguracionSistema {
    private static ConfiguracionSistema instancia;
    private String idioma;
    private int tiempoEspera;
    
    private ConfiguracionSistema(){
        this.idioma = "Espanol";
        this.tiempoEspera = 1;
    }
    
    public static ConfiguracionSistema getInstancia(){
        if(instancia == null){
            instancia = new ConfiguracionSistema();
        }
        return instancia;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public int getTiempoEspera() {
        return tiempoEspera;
    }

    public void setTiempoEspera(int tiempoEspera) {
        this.tiempoEspera = tiempoEspera;
    }
    
}
